package highframe.core;

import OpenCOM.IUnknown;

public interface Runner extends IUnknown {
	public void run();
}
