package comanche.fraclet;

public interface IScheduler {
	void schedule (Runnable task);
}