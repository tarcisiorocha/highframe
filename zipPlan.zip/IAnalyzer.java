package comanche.fraclet;

public interface IAnalyzer {
  Response handleRequest (Request r) throws java.io.IOException;
}
